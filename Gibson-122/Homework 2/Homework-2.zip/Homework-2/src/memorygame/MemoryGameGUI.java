package memorygame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSlider;

/**
 *
 * @author John Gibson
 */
public class MemoryGameGUI {

    static int delay = 500;
    static double bestTime;
    
    public static void setDelay(int n) {
        delay = n;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        JFrame frame = new JFrame("Main Menu");
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        JLabel instructions = new JLabel("Please select the delay for flipping tiles.");
        instructions.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        
        JSlider delaySlider = new JSlider(100, 1000, 500);
        delaySlider.setPaintLabels(true);
        delaySlider.setPaintTicks(true);
        delaySlider.setMajorTickSpacing(100);
        delaySlider.setAlignmentX(JSlider.CENTER_ALIGNMENT);
        
        JButton startGame = new JButton("Start Game");
        startGame.setAlignmentX(JButton.CENTER_ALIGNMENT);
        
        frame.add(instructions);
        frame.add(delaySlider);
        frame.add(startGame);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setSize(400, 150);
        
        startGame.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent ae) {
                setDelay(delaySlider.getValue());
                MemoryGame mg = new MemoryGame(delay);
            }
        });
    }

}